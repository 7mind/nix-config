############################################################################
# macros.cmake
# Copyright (C) 2026 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################

macro(sofiasip_target_set_public_headers target)
	set_target_properties(${target} PROPERTIES PUBLIC_HEADER "${ARGN}")
endmacro()

macro(sofia_configure_file src dest base type)
	# Ensure the destination directory is created
	get_filename_component(outputdir "${CMAKE_CURRENT_BINARY_DIR}/${dest}" DIRECTORY)
	execute_process(COMMAND "${CMAKE_COMMAND}" -E make_directory "${outputdir}")

	add_custom_command(OUTPUT ${dest}
		COMMAND ${AWK_MSG_AWK} ${ARGN}
		${type}=${CMAKE_CURRENT_BINARY_DIR}/${dest} TEMPLATE=${src} ${base}
		DEPENDS ${base} ${MSG_PARSER_AWK} ${src}
		WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}
	)
endmacro(sofia_configure_file)

macro(sofia_add_tag_awk_command src dest)
	set(tag_dll_params "NODLL=1")
	if(${ARGC} GREATER 2)
		string(APPEND tag_dll_params " ${ARGV3}")
	endif()
	add_custom_command(OUTPUT ${CMAKE_CURRENT_BINARY_DIR}/${dest}
		COMMAND ${AWK} -f ${TAG_AWK} ${tag_dll_params} REF=${CMAKE_CURRENT_BINARY_DIR}/${dest} ${src}
		DEPENDS ${TAG_AWK} ${src}
		WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}
	)
	unset(tag_dll_params)
endmacro(sofia_add_tag_awk_command)
