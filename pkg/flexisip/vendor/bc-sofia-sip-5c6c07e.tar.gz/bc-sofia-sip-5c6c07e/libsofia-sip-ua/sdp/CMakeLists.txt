############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################

sofia_add_tag_awk_command(sdp_tag.c sdp_tag_ref.c)

add_library(sdp STATIC
	sdp.c
	sdp_parse.c
	sdp_print.c
	sdp_tag.c
	sdp_tag_ref.c
)
sofiasip_target_set_public_headers(sdp
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/sdp.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/sdp_tag.h
)
target_compile_options(sdp PRIVATE -fPIC)
target_include_directories(sdp
	PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
)
target_link_libraries(sdp PUBLIC su)

if(BUILD_TESTING)
	add_executable(torture_sdp torture_sdp.c)
	target_link_libraries(torture_sdp PRIVATE sdp)
	add_test(NAME torture_sdp COMMAND torture_sdp)

	add_executable(test_sdp test_sdp.c)
	target_link_libraries(test_sdp PRIVATE sdp)
	configure_file(run_test_sdp run_test_sdp COPYONLY)
	add_test(NAME test_sdp COMMAND run_test_sdp ./test_sdp "${CMAKE_CURRENT_SOURCE_DIR}/tests")
endif()
