############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################


sofia_add_tag_awk_command(nea_tag.c nea_tag_ref.c)

add_library(nea STATIC
	nea.c
	nea_debug.c nea_debug.h
	nea_event.c
	nea_server.c
	nea_tag.c
	${CMAKE_CURRENT_BINARY_DIR}/nea_tag_ref.c
)
sofiasip_target_set_public_headers(nea
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nea.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nea_tag.h
)
target_compile_options(nea PRIVATE -fPIC)
target_include_directories(nea
	PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
)
target_link_libraries(nea PUBLIC nta sip su url)
