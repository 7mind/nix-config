############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################


sofia_add_tag_awk_command(nta_tag.c nta_tag_ref.c)

add_library(nta STATIC
	nta.c
	nta_check.c
	nta_internal.h
	nta_tag.c
	nta_tag_ref.c
	sl_read_payload.c
	sl_utils_log.c
	sl_utils_print.c
)
sofiasip_target_set_public_headers(nta
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nta.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nta_stateless.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nta_tag.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nta_tport.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/sl_utils.h
)
target_compile_options(nta PRIVATE -fPIC)
target_include_directories(nta
	PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
)
target_link_libraries(nta
	PUBLIC sip su url
	PRIVATE ipt sresolv tport
)

if(BUILD_TESTING)
	# Portbind is used by some testers
	add_executable(portbind portbind.c)
	target_link_libraries(portbind PRIVATE su)

	set(TESTERS
		test_nta_api
		test_nta
	)
	foreach(tester ${TESTERS})
		add_executable(${tester} ${tester}.c)
		target_link_libraries(${tester} PRIVATE features nta s2 sresolv)
		configure_file("run_${tester}" "run_${tester}" COPYONLY)
		add_test(NAME ${tester} COMMAND "env" "srcdir=${CMAKE_CURRENT_SOURCE_DIR}" "${CMAKE_CURRENT_BINARY_DIR}/run_${tester}")
	endforeach(tester)

	add_executable(check_nta
		check_nta_api.c
		check_nta.c check_nta.h
		check_nta_client.c
		check_nta_server.c
	)
	target_link_libraries(check_nta PRIVATE nta s2 sresolv)
	configure_file(run_check_nta run_check_nta COPYONLY)
	add_test(NAME check_nta COMMAND "${CMAKE_CURRENT_BINARY_DIR}/run_check_nta")
endif()
