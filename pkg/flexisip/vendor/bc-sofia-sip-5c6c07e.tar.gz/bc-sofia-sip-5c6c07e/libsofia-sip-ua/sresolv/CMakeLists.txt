############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################

add_library(sresolv STATIC
#	resolve_sip.c
	sres_blocking.c
	sres.c
	sres_cache.c
	sresolv.c
	sres_sip.c
)
sofiasip_target_set_public_headers(sresolv
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/sresolv.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/sres_sip.h
)
target_compile_options(sresolv PRIVATE -fPIC)
target_include_directories(sresolv
	PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
)
target_link_libraries(sresolv PUBLIC su url)

if(BUILD_TESTING)
	foreach(tester torture_sresolv check_sres_sip)
		add_executable(${tester} ${tester}.c)
		target_link_libraries(${tester} PRIVATE sresolv s2)
		add_test(NAME ${tester} COMMAND ${tester})
	endforeach()

	add_executable(test_sresolv test_sresolv.c)
	target_link_libraries(test_sresolv PRIVATE sresolv s2)
	configure_file(run_test_sresolv run_test_sresolv COPYONLY)
	foreach(zone_file example.com root.zone 194.2.188 127.zone 3.f.f.e.1.2.0.0.3.0.1.2.c.0.0.0 3.f.f.e.1.2.0.0.3.0.1.2.c.0.0.0.arpa)
		configure_file(${zone_file} ${zone_file} COPYONLY)
	endforeach()
	add_test(NAME test_sresolv COMMAND run_test_sresolv)
endif()
