############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################


sofia_add_tag_awk_command(nth_tag.c nth_tag_ref.c)

add_library(nth STATIC
	nth_client.c
	nth_server.c
	nth_tag.c
	${CMAKE_CURRENT_BINARY_DIR}/nth_tag_ref.c
)
sofiasip_target_set_public_headers(nth
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nth.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nth_tag.h
)
target_compile_options(nth PRIVATE -fPIC)
target_include_directories(nth
	PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
)
target_link_libraries(nth
	PUBLIC http su url
	PRIVATE iptsec tport
)

if(BUILD_TESTING)
	add_executable(test_nth test_nth.c)
	target_link_libraries(test_nth PRIVATE iptsec nth tport)
	add_test(NAME test_nth COMMAND test_nth)

	if(BUILD_TESTING_TOOLS)
		foreach(tool http-client http-server)
			add_executable(${tool} ${tool}.c)
			target_link_libraries(${tool} PRIVATE iptsec nth tport)
		endforeach()
	endif()
endif()
