############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################


sofia_add_tag_awk_command(url_tag.c url_tag_ref.c)

add_library(url STATIC
	url.c
	urlmap.c urlmap.h
	url_tag.c
	url_tag_ref.c
)
sofiasip_target_set_public_headers(url
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/url.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/url_tag_class.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/url_tag.h
)
target_compile_options(url PRIVATE -fPIC)
target_include_directories(url
	PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
)
target_link_libraries(url
	PUBLIC bnf su
)


if(BUILD_TESTING)
	add_executable(torture_url torture_url.c)
	target_link_libraries(torture_url PRIVATE url)
	add_test(NAME torture_url COMMAND torture_url)
endif()
