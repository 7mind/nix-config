/*
 * This file is part of the Sofia-SIP package
 *
 * Copyright (C) 2026 Belledonne Communications SARL, All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 *
 */

/**@CFILE test_tport_shared.h
 *
 * Shared test tools used by tport test suites.
 *
 * @internal
 */

#ifndef TEST_TPORT_SHARED_H
#define TEST_TPORT_SHARED_H

typedef struct tp_test_s tp_test_t;

#define TP_STACK_T tp_test_t
#define TP_CLIENT_T struct called

#if HAVE_SIGCOMP
#include <sigcomp.h>
#endif

#include <sofia-sip/su_md5.h>
#include <sofia-sip/tport.h>

struct tp_test_s {
  su_home_t     tt_home[1];
  int           tt_flags;
  su_root_t    *tt_root;
  msg_mclass_t *tt_mclass;
  tport_t      *tt_srv_tports;
  tport_t      *tt_tports;

  tport_t *tt_rtport;

  tp_name_t tt_udp_name[1];
  tp_name_t tt_udp_comp[1];

  tp_name_t tt_tcp_name[1];
  tp_name_t tt_tcp_comp[1];

  tp_name_t tt_sctp_name[1];
  tp_name_t tt_sctp_comp[1];

  tp_name_t tt_tls_name[1];
  tp_name_t tt_tls_comp[1];

#if HAVE_SIGCOMP
  struct sigcomp_state_handler   *state_handler;
  struct sigcomp_algorithm const *algorithm;
  struct sigcomp_compartment     *master_cc;

#define IF_SIGCOMP_TPTAG_COMPARTMENT(cc) TAG_IF(cc, TPTAG_COMPARTMENT(cc)),
#else
#define IF_SIGCOMP_TPTAG_COMPARTMENT(cc)
#endif

  int     tt_status;
  int     tt_received;
  msg_t  *tt_rmsg;
  uint8_t tt_digest[SU_MD5_DIGEST_SIZE];

  su_addrinfo_t const *tt_tcp_addr;
  tport_t             *tt_tcp;
};

#define TPORT_TEST_VERSION MSG_TEST_VERSION_CURRENT

int check_msg(tp_test_t *tt, msg_t *msg, char const *ident);
int test_create_md5(tp_test_t *tt, msg_t *msg);
int test_check_md5(tp_test_t *tt, msg_t *msg);
int new_test_msg(tp_test_t  *tt,
		 msg_t     **retval,
		 char const *ident,
		 int         N,
		 int         len);

msg_t *tp_test_msg(tp_test_t     *tt,
		   int            flags,
		   char const     data[],
		   usize_t        size,
		   tport_t const *tp,
		   tp_client_t   *tpc);

int test_sigcomp_accept(tp_stack_t *tt, tport_t *tp, msg_t *msg);
int init_test(tp_test_t *tt);
int deinit_test(tp_test_t *tt);
int tport_test_run(tp_test_t *tt, unsigned timeout);

extern tp_stack_class_t const tp_test_class[1];

#endif // TPORT_TEST_H