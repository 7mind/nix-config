/*
 * This file is part of the Sofia-SIP package
 *
 * Copyright (C) 2026 Belledonne Communications SARL, All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 *
 */

/**@CFILE test_tport_timeout.c
 *
 * Test transport timeout feature.
 *
 * @internal
 */

/* always assert()s */
#undef NDEBUG

#include "test_tport_shared.h"

#include "config.h"

#include <assert.h>
#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sofia-sip/base64.h>
#include <sofia-sip/msg.h>
#include <sofia-sip/su_localinfo.h>
#include <sofia-sip/su_log.h>
#include <sofia-sip/su_md5.h>
#include <sofia-sip/su_wait.h>
#include <sofia-sip/tport.h>

int tstflags = 0;
#define TSTFLAGS tstflags

#include <sofia-sip/tstdef.h>

char const name[] = "test_tport_timeout";

SOFIAPUBVAR su_log_t tport_log[];

static int connection_establishment_timeout(tp_test_t       *tt,
					    tp_name_t const *tpn) {
  msg_t    *msg = NULL;
  tport_t  *tp  = NULL;
  su_time_t started;

  char const *host = getenv("TPORT_TEST_CONNECTION_TIMEOUT_HOST");
  char const *port = getenv("TPORT_TEST_CONNECTION_TIMEOUT_PORT");
  tp_name_t   tp_name[1];
  unsigned    timeout_value = 0;
  tport_t    *tp_timeout    = NULL;

  BEGIN();

  assert(host != NULL && host[0] != '\0' &&
	 "invalid host in TPORT_TEST_CONNECTION_TIMEOUT_HOST");
  assert(port != NULL && port[0] != '\0' &&
	 "invalid port in TPORT_TEST_CONNECTION_TIMEOUT_PORT");

  *tp_name           = *tpn;
  tp_name->tpn_host  = host;
  tp_name->tpn_port  = port;
  tp_name->tpn_ident = NULL;

  TEST_1(!new_test_msg(tt, &msg, "tcp-timeout", 1, 1024));
  TEST_1(tp = tport_tsend(tt->tt_tports, msg, tp_name, TAG_END()));
  TEST_1(tp_timeout = tport_incref(tp));
  msg_destroy(msg), msg = NULL;

  TEST(tport_set_params(tp_timeout, TPTAG_CONNECTION_TIMEOUT(500), TAG_END()),
       1);
  TEST(tport_get_params(tp_timeout, TPTAG_CONNECTION_TIMEOUT_REF(timeout_value),
			TAG_END()),
       1);
  TEST(timeout_value, 500);

  started = su_now();
  while (su_duration(su_now(), started) < 2500) {
    su_root_step(tt->tt_root, 50);
    if (tport_is_closed(tp_timeout)) break;
  }

  TEST_1(su_duration(su_now(), started) >= 500);
  TEST(tport_is_closed(tp_timeout), 1);
  tport_decref(&tp_timeout);

  // Reset state for next test.
  tt->tt_status = 0;
  tt->tt_rtport = NULL;
  msg_destroy(tt->tt_rmsg), tt->tt_rmsg = NULL;

  END();
}

static int tcp_connection_establishment_timeout(tp_test_t *tt) {
  return connection_establishment_timeout(tt, tt->tt_tcp_name);
}

static int tls_connection_establishment_timeout(tp_test_t *tt) {
#if !HAVE_TLS
  puts("TLS not supported, skipping TLS connection establishment timeout test");
  return 0;
#endif
  return connection_establishment_timeout(tt, tt->tt_tls_name);
}

#if HAVE_ALARM
#include <signal.h>

static RETSIGTYPE sig_alarm(int s) {
  fprintf(stderr, "%s: FAIL! test timeout!\n", name);
  exit(1);
}

char const alarm_option[] = " [--no-alarm]";

#else
char const alarm_option[] = "";
#endif

void usage(int exitcode) {
  fprintf(stderr, "usage: %s [-v] [-a]%s\n", name, alarm_option);
  exit(exitcode);
}

int main(int argc, char *argv[]) {
  int retval   = 0;
  int no_alarm = 0;
  int i;

  tp_test_t tt[1] = {{{SU_HOME_INIT(tt)}}};

  for (i = 1; argv[i]; i++) {
    if (strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--verbatim") == 0)
      tstflags |= tst_verbatim;
    else if (strcmp(argv[i], "-a") == 0 || strcmp(argv[i], "--abort") == 0)
      tstflags |= tst_abort;
    else if (strcmp(argv[i], "--no-alarm") == 0) no_alarm = 1;
    else usage(1);
  }

#if HAVE_OPEN_C
  tstflags |= tst_verbatim;
#endif

#if HAVE_ALARM
  if (!no_alarm) {
    signal(SIGALRM, sig_alarm);
    alarm(120);
  }
#endif

  /* Use log */
  if (tstflags & tst_verbatim) {
    tport_log->log_default = 9;
  } else {
    tport_log->log_default = 1;
  }

  su_init();

  retval |= init_test(tt);
  fflush(stdout);
  if (retval == 0) {
    retval |= tcp_connection_establishment_timeout(tt);
    fflush(stdout);
    retval |= tls_connection_establishment_timeout(tt);
    fflush(stdout);
    retval |= deinit_test(tt);
    fflush(stdout);
  }

  su_deinit();

#if HAVE_OPEN_C
  sleep(10);
#endif

  return retval;
}
