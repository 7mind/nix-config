############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################


find_package(OpenSSL REQUIRED)

sofia_add_tag_awk_command(tport_tag.c tport_tag_ref.c)

add_library(tport STATIC
	tport.c
	tport_internal.h
	tport_logging.c
#	tport_rand.c
#	tport_sigcomp.c
	tport_stub_sigcomp.c
	tport_stub_stun.c
	tport_tag.c
#	tport_threadpool.c
	tport_tls.c tport_tls.h
	tport_type_connect.c
	tport_type_sctp.c
	tport_type_stun.c
	tport_type_tcp.c
	tport_type_tls.c
	tport_type_udp.c
	${CMAKE_CURRENT_BINARY_DIR}/tport_tag_ref.c
)
sofiasip_target_set_public_headers(tport
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/tport.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/tport_plugins.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/tport_tag.h
)
target_compile_options(tport PRIVATE -fPIC)
target_include_directories(tport
	PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
)
target_link_libraries(tport
	PUBLIC msg stun su url OpenSSL::SSL
	PRIVATE http
)
add_dependencies(tport http msg)

if(BUILD_TESTING)
	add_library(test-tport-shared STATIC test_tport_shared.c test_tport_shared.h)
	target_link_libraries(test-tport-shared PRIVATE msg ipt tport)
	configure_file(agent.pem agent.pem COPYONLY)

	foreach(tester test_tport test_tport_timeout)
		add_executable(${tester} ${tester}.c)
		target_link_libraries(${tester} PRIVATE test-tport-shared msg-test ipt tport)
		add_test(NAME ${tester} COMMAND ${tester} -v WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR})
	endforeach()

	# Address from the TEST-NET-1 block reserved for documentation and example code (RFC 5737)
	# Requests targeting this address must not be answered (no ICMP response or connection refused).
	set_tests_properties(test_tport_timeout
		PROPERTIES ENVIRONMENT
		"TPORT_TEST_CONNECTION_TIMEOUT_HOST=192.0.2.1;TPORT_TEST_CONNECTION_TIMEOUT_PORT=12345"
	)
endif()
