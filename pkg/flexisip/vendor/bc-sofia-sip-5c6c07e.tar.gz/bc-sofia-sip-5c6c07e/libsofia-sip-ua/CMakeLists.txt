############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################


find_program(AWK awk)
find_program(ENV_EXECUTABLE env)
set(MSG_PARSER_AWK ${CMAKE_CURRENT_SOURCE_DIR}/msg/msg_parser.awk)
set(TAG_AWK ${CMAKE_CURRENT_SOURCE_DIR}/su/tag_dll.awk)
set(AWK_MSG_AWK ${ENV_EXECUTABLE} LC_ALL=C ${AWK} -f ${MSG_PARSER_AWK})

set(sofia_sip_subprojects "bnf" "features" "http" "ipt" "iptsec" "msg" "nea" "nta" "nth"
	"nua" "sdp" "sip" "soa" "sresolv" "stun" "su" "tport" "url")

add_library(sofia-sip-ua STATIC dummy.c)
foreach(subproject ${sofia_sip_subprojects})
	add_subdirectory("${subproject}")
	list(APPEND sofia_sip_public_headers $<TARGET_PROPERTY:${subproject},PUBLIC_HEADER>)
	list(APPEND sofia_sip_interface_include_dirs $<TARGET_PROPERTY:${subproject},INTERFACE_INCLUDE_DIRECTORIES>)
	target_link_libraries(sofia-sip-ua PUBLIC ${subproject})
	if(ENABLE_COVERAGE)
		if(CMAKE_C_COMPILER_ID MATCHES "^GNU$")
			target_compile_options(${subproject} PRIVATE "-coverage")
			target_link_options(${subproject} PRIVATE "-coverage")
			target_link_libraries(${subproject} PRIVATE gcov)
		else()
			message(FATAL " CMAKE_C_COMPILER_ID is set to ${CMAKE_C_COMPILER_ID}. Coverage works only under GCC. Disable ENABLE_COVERAGE option or use GCC.")
		endif()
	endif()
endforeach()
set_target_properties(sofia-sip-ua PROPERTIES
	SOVERSION "0"
	VERSION "0.6.0"
	PUBLIC_HEADER "${sofia_sip_public_headers}"
	INTERFACE_INCLUDE_DIRECTORIES "${sofia_sip_interface_include_dirs}"
)

include(GNUInstallDirs)
install(TARGETS sofia-sip-ua
	LIBRARY
		DESTINATION "${CMAKE_INSTALL_LIBDIR}"
	PUBLIC_HEADER
		DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}/sofia-sip-${PROJECT_VERSION_MAJOR}.${PROJECT_VERSION_MINOR}/sofia-sip"
)
