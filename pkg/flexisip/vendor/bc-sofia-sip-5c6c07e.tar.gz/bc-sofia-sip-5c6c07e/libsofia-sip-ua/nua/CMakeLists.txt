############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################


sofia_add_tag_awk_command("${CMAKE_CURRENT_SOURCE_DIR}/nua_tag.c" "nua_tag_ref.c" "nua_tag_list")

add_library(nua STATIC
	nua.c
	nua_client.c nua_client.h
	nua_common.c
	nua_dialog.c nua_dialog.h
	nua_event_server.c
	nua_extension.c
	nua_message.c
	nua_notifier.c
	nua_options.c
	nua_params.c nua_params.h
	nua_publish.c
	nua_register.c
	nua_registrar.c
	nua_server.c nua_server.h
	nua_session.c
	nua_stack.c nua_stack.h
	nua_subnotref.c
	nua_tag.c
	nua_tag_ref.c
	nua_types.h
	outbound.c outbound.h
)
sofiasip_target_set_public_headers(nua
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nua.h
	${CMAKE_CURRENT_SOURCE_DIR}/sofia-sip/nua_tag.h
)
target_compile_options(nua PRIVATE -fPIC)
target_include_directories(nua
	PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
)
target_link_libraries(nua
	PUBLIC nea nta sdp sip soa su url
	PRIVATE ipt iptsec stun tport
)

if(BUILD_TESTING)
	add_executable(check_nua
		check_etsi.c
		check_nua.c check_nua.h
		check_register.c
		check_session.c
		check_simple.c
	)
	target_link_libraries(check_nua PRIVATE nua s2 sresolv)
	configure_file(run_check_nua run_check_nua COPYONLY)
	add_test(NAME check_nua COMMAND "${CMAKE_CURRENT_BINARY_DIR}/run_check_nua")
endif()
