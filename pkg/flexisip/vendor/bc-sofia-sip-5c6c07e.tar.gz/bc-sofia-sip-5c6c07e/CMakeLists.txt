############################################################################
# CMakeLists.txt
# Copyright (C) 2019 Belledonne Communications, Grenoble France
#
############################################################################
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
############################################################################

cmake_minimum_required(VERSION 3.25)

# CMP0077 policy is required by Flexisip build.
cmake_policy(SET CMP0077 NEW)

project(sofia-sip VERSION 1.13.33 LANGUAGES C)

# The BUILD_TESTING option is added when including CTest but we want to have it disabled by default
option(BUILD_TESTING "Build tests" OFF)
option(BUILD_TESTING_TOOLS "Build executable useful for testing" OFF)

include(CMakeDependentOption)
cmake_dependent_option(ENABLE_COVERAGE "Enable gcc test coverage reports (add instrumentation)" OFF BUILD_TESTING OFF)

include(cmake/macros.cmake)

find_package(OpenSSL REQUIRED)

if(BUILD_TESTING)
	include(FindPkgConfig)
	include(CTest)
	list(APPEND CMAKE_MODULE_PATH ${CMAKE_CURRENT_SOURCE_DIR}/cmake)
	find_package(Check REQUIRED)
	set(HAVE_CHECK YES)
endif()

include(CheckCSourceCompiles)
include(CheckIncludeFile)
include(CheckSymbolExists)
check_symbol_exists("clock_getcpuclockid" "time.h" HAVE_CLOCK_GETCPUCLOCKID)
check_include_file("netpacket/packet.h" HAVE_NETPACKET_PACKET_H)
check_include_file("sys/epoll.h" HAVE_EPOLL)
check_c_source_compiles("
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	int main(void) {
		int one = 1;
		int s = 0;
		setsockopt(s, IPPROTO_IP, IP_MTU_DISCOVER, &one, sizeof(one));
		return 0;
	}	"
	HAVE_IP_MTU_DISCOVER	
)
check_c_source_compiles("
	#include <sys/types.h>
	#include <sys/socket.h>
	int main(void) {
		int one = 1;
		int s = 0;
		setsockopt(s, SOL_SOCKET, SO_RCVBUFFORCE, &one, sizeof(one));
		return 0;
	}	"
	HAVE_SO_RCVBUFFORCE
)
check_c_source_compiles("
	#include <sys/types.h>
	#include <sys/socket.h>
	int main(void) {
		int one = 1;
		int s = 0;
		setsockopt(s, SOL_SOCKET, SO_SNDBUFFORCE, &one, sizeof(one));
		return 0;
	}	"
	HAVE_SO_SNDBUFFORCE
)
check_c_source_compiles("
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	int main(void) {
		int one = 1;
		int s = 0;
		setsockopt(s, SOL_IP, IP_RECVERR, &one, sizeof(one));
		return 0;
	}	"
	HAVE_IP_RECVERR
)

check_c_source_compiles("
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	int main(void) {
		int one = 1;
		int s = 0;
		setsockopt(s, SOL_IPV6, IPV6_RECVERR, &one, sizeof(one));
		return 0;
	}	"
	HAVE_IPV6_RECVERR
)
configure_file(config.h.cmake config.h)

find_program(GIT_EXECUTABLE git NAMES Git CMAKE_FIND_ROOT_PATH_BOTH)
if(GIT_EXECUTABLE)
	execute_process(
		COMMAND "${GIT_EXECUTABLE}" "describe"
		OUTPUT_VARIABLE PACKAGE_VERSION
		OUTPUT_STRIP_TRAILING_WHITESPACE
		RESULT_VARIABLE GIT_DESCRIBE_STATUS
		WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}"
	)
	if(GIT_DESCRIBE_STATUS EQUAL 0)
		message(STATUS "Sofia-SIP version: ${PACKAGE_VERSION}")
	else()
		message(WARNING "Failed to get Sofia-SIP version through GIT describe command execution")
	endif()
endif()

include_directories(${PROJECT_BINARY_DIR})

add_subdirectory(libsofia-sip-ua)
if(BUILD_TESTING)
	add_subdirectory(s2check)
endif()